<h1>Quiz Uygulaması</h1> <br>
Katkıda bulunmak için projeyi forklayın daha sonra yeni branş açarak pull requestlerinizi dahil edin. <br>
Pull request atarken dbsqlite3 ve migration dosyalarınızı dahil etmeyin. <br>
dbsqlite ve migration dosyalarınız sizin local dosyalarınızdır projede yapılan değişiklikleri uygulamak / test etmek için kendi local databasenizi güncellemeniz gerekir. <br>
<b> <h2>Eğer no such column hatası alıyorsanız </h2></b> <br>
<p>Terminali açıp: <ins>py manage.py makemigrations</ins> daha sonra <ins>py manage.py migrate</ins> komutlarını kullanarak databaseyi güncellemeniz gerekmektedir.</p>

<b> <h2>Projeyi çalıştırmak için gereksinimler</h2></b> <br>
<p>Aşsağıdaki kütüphaneyi kurmanız gerekmektedir:</p>
pip install django-embed-video

<br>
<strong>Not: Projenizi güncellerken localde olan veritabanınızı mutlaka saklayın..</strong>
